$(document).ready(function(){
  $("#error_email").hide();
  $("#error_password").hide();
 var flag_password=false;
 var flag_email=false;
 $("#login").prop('disabled', true);

 function submit_button(){
  if(flag_email===true){
    if(flag_password===true){
      $("#login").prop('disabled', false);
    }
 }
 }


   $("#login").click(function(){
    window.location.href="dasbrd.html";  
  });
 

  $("#email").keyup(function(){
    var email=$("#email").val();
    var regex =  /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if(!regex.test(email)) {
      $("#error_email").show();
      flag_email=false;
    }
    else
    {
    $("#error_email").hide();
    flag_email=true; 
   
    }
    submit_button();
  });


$("#password").keyup(function(){
  var password=$("#password").val();
  console.log(password);
  var mediumRegex = new RegExp("^(((?=.*[a-z])(?=.*[A-Z]))|((?=.*[a-z])(?=.*[0-9]))|((?=.*[A-Z])(?=.*[0-9])))(?=.{6,})");
  if(!mediumRegex.test(password)) {
    $("#error_password").show();
    flag_password=false;
  }
  else
  {
  $("#error_password").hide();
  flag_password=true;
 
  }
  submit_button();
});


}); 








     /*var email=$("#email").val();;
     var password=$("#password").val();;
  var listofobj=[];
       $.ajax({
     url:"https://reqres.in/api/users",
     method:"GET",
    key:{
       email:email,
       password:password
     },
       }).done(function(data){ 
 
        for(var i=0; i<data.data.length;i++){
          var person={
            id:data.data[i].id,
            email:data.data[i].email,
            first_name:data.data[i].first_name,
            last_name:data.data[i].last_name,
          };
            listofobj.push(person);
        }   
         localStorage.setItem('list',JSON.stringify(listofobj)); */
       

     
    

 
  