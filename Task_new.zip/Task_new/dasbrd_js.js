$(document).ready(function(){
     var store_p_data=[];
     var get_data=[];
      var index_data=0;
  display();

$("#p_data_save").click(function(){
   
     var f_name=$("#f_name").val();
     var l_name=$("#l_name").val();
     var contact=$("#contact").val();
     var p_data_email=$("#email_id").val();
     var city=$("#city").val();
     var country=$("#country").val();
     var person_data={
      f_name:f_name,
      l_name:l_name,
      contact:contact,
      p_data_email:p_data_email,
      city:city,
      country:country
     }
    store_p_data.push(person_data);
    localStorage.setItem('p_data_list',JSON.stringify(store_p_data));
    get_data=JSON.parse(localStorage.getItem("p_data_list"));
     display();
     console.log(store_p_data);
     });
     
   









     

function display(){  
     jQuery(".page_down").empty();
     get_data=JSON.parse(localStorage.getItem("p_data_list"));
  
     if(get_data.length===0)
     jQuery(".page_down").append(' <h3>'+"No card infornmation available"+'</h3>');
     
    
     jQuery.each(get_data, function(index, value) {
        
            jQuery(".page_down").append('<div class="card text-center" id="data_pack">'
          + value.f_name +'<br>' 
          + value.l_name +'<br>'
          + value.contact+'<br>'
          + value.p_data_email+'<br>'
          + value.city+'<br>'
          +value.country+'<br>'
          +'<script>$("#edit").click(function(){jQuery("#read").append();});</script><div id="btn"><button type="button" id="edit" data-toggle="modal" data-target="#editModal"><span class="glyphicon glyphicon-edit"></span></button><button type="button" id="delete" data-toggle="modal" data-target="#deleteModal"><span class="glyphicon glyphicon-trash"></span></button></div>'
          +'</div>');
        });
     
}
   //  jQuery("#readonly").append(get_data[0].p_data_email);
   //<input value="get_data[0].p_data_email" readonly>   
 


  $("#p_data_edit").click(function(){
     var f_name=$("#e_f_name").val();
     var l_name=$("#e_l_name").val();
     var contact=$("#e_contact").val();
     var email= get_data[index_data].p_data_email;
     var city=$("#e_city").val();
     var country=$("#e_country").val();
     var person_data={
      f_name:f_name,
      l_name:l_name,
      contact:contact,
      p_data_email:email,
      city:city,
      country:country
     }
get_data[index_data]=person_data;
console.log(get_data);
localStorage.setItem('p_data_list',JSON.stringify(get_data));  
store_p_data=JSON.parse(localStorage.getItem("p_data_list"));  
console.log(store_p_data);
display();

  });    




  $("#p_data_delete").click(function(){
     get_data.splice(index_data, 1);
      console.log(get_data);
      localStorage.setItem('p_data_list',JSON.stringify(get_data));  
      store_p_data=JSON.parse(localStorage.getItem("p_data_list")); 
      console.log(store_p_data); 
display();
});








   
     
          });
       
           
       
     




